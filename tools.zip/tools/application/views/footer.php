<div class="footer-container-wrapper" style="
    margin-top: 50px;
    border-top: 3px solid #3B8CF9;
">
    <div class="footer-container container-fluid">

<div class="row-fluid-wrapper row-depth-1 row-number-1 ">
<div class="row-fluid ">
<div class="span12 widget-span widget-type-global_group " style="" data-widget-type="global_group" data-x="0" data-w="12">
<!-- start coded_template: id:9876203527 path:generated_global_groups/9876203526.html -->
<div class="" data-global-widget-path="generated_global_groups/9876203526.html"><div class="row-fluid-wrapper row-depth-1 row-number-1 ">
<div class="row-fluid ">
<div id="contact" class="span12 widget-span widget-type-cell content-section bg-dark page-section hidden" style="" data-widget-type="cell" data-x="0" data-w="12">

<div class="row-fluid-wrapper row-depth-1 row-number-2 ">
<div class="row-fluid ">
<div class="span12 widget-span widget-type-cell centered md-stack" style="" data-widget-type="cell" data-x="0" data-w="12">

<div class="row-fluid-wrapper row-depth-1 row-number-3 ">
<div class="row-fluid ">
<div class="span3 widget-span widget-type-cell md-mb30" style="" data-widget-type="cell" data-x="0" data-w="3">

<div class="row-fluid-wrapper row-depth-1 row-number-4 ">
<div class="row-fluid ">
<div class="span12 widget-span widget-type-rich_text white-content" style="" data-widget-type="rich_text" data-x="0" data-w="12">
<div class="cell-wrapper layout-widget-wrapper">
<span id="hs_cos_wrapper_module_146731089989916" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_rich_text" style="" data-hs-cos-general-type="widget" data-hs-cos-type="rich_text"><h3>Company, Inc</h3>
<p>Street Address<br>City, ST 00000<br>Call us: <a href="tel:1-800-COMPANY">1-800-COMPANY</a><br><a href="tel:800-000-0000">(800-000-0000)</a></p></span>
</div><!--end layout-widget-wrapper -->
</div><!--end widget-span -->
</div><!--end row-->
</div><!--end row-wrapper -->

<div class="row-fluid-wrapper row-depth-1 row-number-5 ">
<div class="row-fluid ">
<div class="span12 widget-span widget-type-follow_me social-icons" style="" data-widget-type="follow_me" data-x="0" data-w="12">
<div class="cell-wrapper layout-widget-wrapper">
<span id="hs_cos_wrapper_module_146731089989922" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_follow_me" style="" data-hs-cos-general-type="widget" data-hs-cos-type="follow_me"><div style=""></div></span></div><!--end layout-widget-wrapper -->
</div><!--end widget-span -->
</div><!--end row-->
</div><!--end row-wrapper -->

</div><!--end widget-span -->
<div class="span9 widget-span widget-type-cell " style="" data-widget-type="cell" data-x="3" data-w="9">

<div class="row-fluid-wrapper row-depth-1 row-number-6 ">
<div class="row-fluid ">
<div class="span3 widget-span widget-type-cell " style="" data-widget-type="cell" data-x="0" data-w="3">

<div class="row-fluid-wrapper row-depth-2 row-number-1 ">
<div class="row-fluid ">
<div class="span12 widget-span widget-type-simple_menu sub-menu white-content link-hover-theme" style="" data-widget-type="simple_menu" data-x="0" data-w="12">
<div class="cell-wrapper layout-widget-wrapper">
<span id="hs_cos_wrapper_module_15009979105111315" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_simple_menu" style="" data-hs-cos-general-type="widget" data-hs-cos-type="simple_menu"><ul></ul></span>
</div><!--end layout-widget-wrapper -->
</div><!--end widget-span -->
</div><!--end row-->
</div><!--end row-wrapper -->

<div class="row-fluid-wrapper row-depth-2 row-number-2 ">
<div class="row-fluid ">
<div class="span12 widget-span widget-type-simple_menu sub-menu white-content link-hover-theme" style="" data-widget-type="simple_menu" data-x="0" data-w="12">
<div class="cell-wrapper layout-widget-wrapper">
<span id="hs_cos_wrapper_module_15010030751612236" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_simple_menu" style="" data-hs-cos-general-type="widget" data-hs-cos-type="simple_menu"><ul></ul></span>
</div><!--end layout-widget-wrapper -->
</div><!--end widget-span -->
</div><!--end row-->
</div><!--end row-wrapper -->

</div><!--end widget-span -->
<div class="span3 widget-span widget-type-cell sm-mb30" style="" data-widget-type="cell" data-x="3" data-w="3">

<div class="row-fluid-wrapper row-depth-2 row-number-3 ">
<div class="row-fluid ">
<div class="span12 widget-span widget-type-simple_menu sub-menu white-content link-hover-theme" style="" data-widget-type="simple_menu" data-x="0" data-w="12">
<div class="cell-wrapper layout-widget-wrapper">
<span id="hs_cos_wrapper_module_15010029719392159" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_simple_menu" style="" data-hs-cos-general-type="widget" data-hs-cos-type="simple_menu"><ul></ul></span>
</div><!--end layout-widget-wrapper -->
</div><!--end widget-span -->
</div><!--end row-->
</div><!--end row-wrapper -->

<div class="row-fluid-wrapper row-depth-2 row-number-4 ">
<div class="row-fluid ">
<div class="span12 widget-span widget-type-simple_menu sub-menu white-content link-hover-theme" style="" data-widget-type="simple_menu" data-x="0" data-w="12">
<div class="cell-wrapper layout-widget-wrapper">
<span id="hs_cos_wrapper_module_15010029007791712" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_simple_menu" style="" data-hs-cos-general-type="widget" data-hs-cos-type="simple_menu"><ul></ul></span>
</div><!--end layout-widget-wrapper -->
</div><!--end widget-span -->
</div><!--end row-->
</div><!--end row-wrapper -->

</div><!--end widget-span -->
<div class="span6 widget-span widget-type-form white-content form-button-theme mb10" style="" data-widget-type="form" data-x="6" data-w="6">
<div class="cell-wrapper layout-widget-wrapper">
<span id="hs_cos_wrapper_module_15009982909581442" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_form" style="" data-hs-cos-general-type="widget" data-hs-cos-type="form"><h3 id="hs_cos_wrapper_module_15009982909581442_title" class="hs_cos_wrapper form-title" data-hs-cos-general-type="widget_field" data-hs-cos-type="text">Drop us a line</h3>

<div id="hs_form_target_module_15009982909581442"></div>









</span>
</div><!--end layout-widget-wrapper -->
</div><!--end widget-span -->
</div><!--end row-->
</div><!--end row-wrapper -->

</div><!--end widget-span -->
</div><!--end row-->
</div><!--end row-wrapper -->

</div><!--end widget-span -->
</div><!--end row-->
</div><!--end row-wrapper -->

</div><!--end widget-span -->
</div><!--end row-->
</div><!--end row-wrapper -->

<div class="row-fluid-wrapper row-depth-1 row-number-1 ">
<div class="row-fluid ">
<div class="span12 widget-span widget-type-cell content-section pb0 pt40" style="" data-widget-type="cell" data-x="0" data-w="12">

<div class="row-fluid-wrapper row-depth-1 row-number-2 ">
<div class="row-fluid ">
<div class="span12 widget-span widget-type-cell centered" style="" data-widget-type="cell" data-x="0" data-w="12">

<div class="row-fluid-wrapper row-depth-1 row-number-3 ">
<div class="row-fluid ">
<div class="span5 widget-span widget-type-cell " style="" data-widget-type="cell" data-x="0" data-w="5">

<div class="row-fluid-wrapper row-depth-1 row-number-4 ">
<div class="row-fluid ">
<div class="span12 widget-span widget-type-rich_text text-medium pr80 mb30" style="" data-widget-type="rich_text" data-x="0" data-w="12">
<div class="cell-wrapper layout-widget-wrapper">
<span id="hs_cos_wrapper_module_1549885931231687" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_rich_text" style="" data-hs-cos-general-type="widget" data-hs-cos-type="rich_text"><a href="https://www.novastor.com/company/?hsLang=en" rel="noopener">About Us</a><br><a href="https://support.novastor.com/hc/en-us" rel="noopener">Support</a><br><a href="https://www.novabackup.com/products?hsLang=en" rel="noopener">Products</a><br><a href="https://www.novabackup.com/resources/downloads?hsLang=en" rel="noopener">Downloads</a><br><a href="https://www.novabackup.com/partners/partner-program?hsLang=en" rel="noopener">Partners</a><br><a href="https://www.novastor.com/company/careers?hsLang=en" rel="noopener">Careers</a><br><a href="https://www.novabackup.com/blog/?hsLang=en" rel=" noopener">Blog</a></span>
</div><!--end layout-widget-wrapper -->
</div><!--end widget-span -->
</div><!--end row-->
</div><!--end row-wrapper -->

<div class="row-fluid-wrapper row-depth-1 row-number-5 ">
<div class="row-fluid ">
<div class="span12 widget-span widget-type-rich_text text-small pr80 text-footer-grey pt20" style="" data-widget-type="rich_text" data-x="0" data-w="12">
<div class="cell-wrapper layout-widget-wrapper">
<span id="hs_cos_wrapper_module_15010032072222438" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_rich_text" style="" data-hs-cos-general-type="widget" data-hs-cos-type="rich_text"><p>© 2019 NovaStor. All Rights Reserved.<br><span style="color: #ffffff;"><a href="https://www.novabackup.com/terms?hsLang=en" rel="noopener" target="_blank" style="color: #8c8c8c;">Terms</a></span>&nbsp;|&nbsp;<span style="color: #8c8c8c;"><a href="https://www.novabackup.com/privacy-policy?hsLang=en" rel="noopener" target="_blank" style="color: #8c8c8c;">Privacy</a></span>&nbsp;|&nbsp;<span style="color: #8c8c8c;"><a href="https://www.novabackup.com/sitemap?hsLang=en" rel="noopener" target="_blank" style="color: #8c8c8c;">Sitemap</a></span></p></span>
</div><!--end layout-widget-wrapper -->
</div><!--end widget-span -->
</div><!--end row-->
</div><!--end row-wrapper -->

</div><!--end widget-span -->
<div class="span3 widget-span widget-type-cell " style="" data-widget-type="cell" data-x="5" data-w="3">

<div class="row-fluid-wrapper row-depth-1 row-number-6 ">
<div class="row-fluid ">
<div class="span12 widget-span widget-type-custom_widget text-medium pr80 mb30" style="" data-widget-type="custom_widget" data-x="0" data-w="12">
<div id="hs_cos_wrapper_module_1550220944742539" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_module widget-type-rich_text" style="" data-hs-cos-general-type="widget" data-hs-cos-type="module"><span id="hs_cos_wrapper_module_1550220944742539_" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_rich_text" style="" data-hs-cos-general-type="widget" data-hs-cos-type="rich_text"><p>NovaStor Corporation<br>29209 Canwood St.<br>Agoura Hills, CA 91301 USA</p>
<p>Tel.: <a href="tel:1-805-579-6700">+1&nbsp;805-579-6700</a><br>Fax.:&nbsp;<span>+1</span><span>&nbsp;805-579-6710<br></span><a href="mailto:ols@novastor.com">ols@novastor.com</a></p></span></div>

</div><!--end widget-span -->
</div><!--end row-->
</div><!--end row-wrapper -->

</div><!--end widget-span -->
<div class="span4 widget-span widget-type-cell " style="" data-widget-type="cell" data-x="8" data-w="4">

<div class="row-fluid-wrapper row-depth-1 row-number-7 ">
<div class="row-fluid ">
<div class="span12 widget-span widget-type-custom_widget social-icons pb20" style="" data-widget-type="custom_widget" data-x="0" data-w="12">
<div id="hs_cos_wrapper_module_1550220723889529" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_module" style="" data-hs-cos-general-type="widget" data-hs-cos-type="module"><div class="">
  <div class="hs_cos_wrapper_type_follow_me">
    <div>
      
      	
      		<a href="https://www.linkedin.com/company/novastor-corporation" class="fm_button fm_linkedin" target="_blank"></a>
      	
      
      	
      		<a href="https://twitter.com/NovaStor" class="fm_button fm_twitter" target="_blank"></a>
      	
      
      	
      		<a href="https://www.facebook.com/NovaStor" class="fm_button fm_facebook" target="_blank"></a>
      	
      
      	
      		<a href="https://www.youtube.com/user/novastor" class="fm_button fm_youtube" target="_blank"></a>
      	
      
    </div>
  </div>
</div></div>

</div><!--end widget-span -->
</div><!--end row-->
</div><!--end row-wrapper -->

<div class="row-fluid-wrapper row-depth-1 row-number-8 ">
<div class="row-fluid ">
<div class="span12 widget-span widget-type-custom_widget text-medium text-footer-grey pb20" style="" data-widget-type="custom_widget" data-x="0" data-w="12">
<div id="hs_cos_wrapper_module_1550225259855181" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_module widget-type-rich_text" style="" data-hs-cos-general-type="widget" data-hs-cos-type="module"><span id="hs_cos_wrapper_module_1550225259855181_" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_rich_text" style="" data-hs-cos-general-type="widget" data-hs-cos-type="rich_text">Newsletter signup:</span></div>

</div><!--end widget-span -->
</div><!--end row-->
</div><!--end row-wrapper -->

<div class="row-fluid-wrapper row-depth-1 row-number-9 ">
<div class="row-fluid ">
<div class="span12 widget-span widget-type-custom_widget one-field-form form-button-theme mb20 pb10 nbk-hs-form sm-mb100" style="" data-widget-type="custom_widget" data-x="0" data-w="12">
<div id="hs_cos_wrapper_module_1550221074219543" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_module widget-type-form" style="" data-hs-cos-general-type="widget" data-hs-cos-type="module"> 
	

 

	<span id="hs_cos_wrapper_module_1550221074219543_" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_form" style="" data-hs-cos-general-type="widget" data-hs-cos-type="form">
<div id="hs_form_target_module_1550221074219543"><form novalidate="" accept-charset="UTF-8" action="https://forms.hsforms.com/submissions/v3/public/submit/formsnext/multipart/1962294/c675ff17-5670-48c4-b23a-d095a334110b" enctype="multipart/form-data" id="hsForm_c675ff17-5670-48c4-b23a-d095a334110b_2711" method="POST" class="hs-form stacked hs-custom-form hs-form-private hsForm_c675ff17-5670-48c4-b23a-d095a334110b hs-form-c675ff17-5670-48c4-b23a-d095a334110b hs-form-c675ff17-5670-48c4-b23a-d095a334110b_3cac1795-67e8-4ee8-9e51-7aeb145b96ca" data-form-id="c675ff17-5670-48c4-b23a-d095a334110b" data-portal-id="1962294" target="target_iframe_c675ff17-5670-48c4-b23a-d095a334110b_2711" data-reactid=".hbspt-forms-1"><div class="hs_email hs-email hs-fieldtype-text field hs-form-field" data-reactid=".hbspt-forms-1.1:$0"><label id="label-email-c675ff17-5670-48c4-b23a-d095a334110b_2711" class="" placeholder="Enter your Email" for="email-c675ff17-5670-48c4-b23a-d095a334110b_2711" data-reactid=".hbspt-forms-1.1:$0.0"><span data-reactid=".hbspt-forms-1.1:$0.0.0">Email</span><span class="hs-form-required" data-reactid=".hbspt-forms-1.1:$0.0.1">*</span></label><legend class="hs-field-desc" style="display:none;" data-reactid=".hbspt-forms-1.1:$0.1"></legend><div class="input" data-reactid=".hbspt-forms-1.1:$0.$email"><input id="email-c675ff17-5670-48c4-b23a-d095a334110b_2711" class="hs-input" type="email" name="email" required="" placeholder="" value="brendon.eby@novastor.com" autocomplete="email" data-reactid=".hbspt-forms-1.1:$0.$email.0" style="padding-right: 135px;"></div></div><div class="hs_blog_novastor_blog_7996513325_subscription hs-blog_novastor_blog_7996513325_subscription hs-fieldtype-radio field hs-form-field" style="display:none;" data-reactid=".hbspt-forms-1.1:$1"><label id="label-blog_novastor_blog_7996513325_subscription-c675ff17-5670-48c4-b23a-d095a334110b_2711" class="" placeholder="Enter your Notification Frequency" for="blog_novastor_blog_7996513325_subscription-c675ff17-5670-48c4-b23a-d095a334110b_2711" data-reactid=".hbspt-forms-1.1:$1.0"><span data-reactid=".hbspt-forms-1.1:$1.0.0">Notification Frequency</span></label><legend class="hs-field-desc" style="display:none;" data-reactid=".hbspt-forms-1.1:$1.1"></legend><div class="input" data-reactid=".hbspt-forms-1.1:$1.$blog_novastor_blog_7996513325_subscription"><input name="blog_novastor_blog_7996513325_subscription" class="hs-input" type="hidden" value="" data-reactid=".hbspt-forms-1.1:$1.$blog_novastor_blog_7996513325_subscription.0" style="padding-right: 135px;"></div></div><div class="hs_lifecyclestage hs-lifecyclestage hs-fieldtype-radio field hs-form-field" style="display:none;" data-reactid=".hbspt-forms-1.1:$2"><label id="label-lifecyclestage-c675ff17-5670-48c4-b23a-d095a334110b_2711" class="" placeholder="Enter your Lifecycle Stage" for="lifecyclestage-c675ff17-5670-48c4-b23a-d095a334110b_2711" data-reactid=".hbspt-forms-1.1:$2.0"><span data-reactid=".hbspt-forms-1.1:$2.0.0">Lifecycle Stage</span></label><legend class="hs-field-desc" style="display:none;" data-reactid=".hbspt-forms-1.1:$2.1"></legend><div class="input" data-reactid=".hbspt-forms-1.1:$2.$lifecyclestage"><input name="lifecyclestage" class="hs-input" type="hidden" value="subscriber" data-reactid=".hbspt-forms-1.1:$2.$lifecyclestage.0" style="padding-right: 135px;"></div></div><noscript data-reactid=".hbspt-forms-1.2"></noscript><div class="hs_submit hs-submit" data-reactid=".hbspt-forms-1.5"><div class="hs-field-desc" style="display:none;" data-reactid=".hbspt-forms-1.5.0"></div><div class="actions" data-reactid=".hbspt-forms-1.5.1"><input type="submit" value="Subscribe" class="hs-button primary large" data-reactid=".hbspt-forms-1.5.1.0"></div></div><noscript data-reactid=".hbspt-forms-1.6"></noscript><input name="hs_context" type="hidden" value="{&quot;rumScriptExecuteTime&quot;:1868.9550000126474,&quot;rumServiceResponseTime&quot;:2659.539999993285,&quot;rumFormRenderTime&quot;:1.6949999844655395,&quot;rumTotalRenderTime&quot;:2701.1599999968894,&quot;rumTotalRequestTime&quot;:779.6450000023469,&quot;embedAtTimestamp&quot;:&quot;1587263612364&quot;,&quot;formDefinitionUpdatedAt&quot;:&quot;1551956218414&quot;,&quot;pageUrl&quot;:&quot;https://www.novabackup.com/&quot;,&quot;pageTitle&quot;:&quot;NovaBACKUP, The #1 Windows Backup Software&quot;,&quot;source&quot;:&quot;FormsNext-static-3.480&quot;,&quot;timestamp&quot;:1587263612366,&quot;userAgent&quot;:&quot;Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36&quot;,&quot;originalEmbedContext&quot;:{&quot;formsBaseUrl&quot;:&quot;/_hcms/forms/&quot;,&quot;portalId&quot;:&quot;1962294&quot;,&quot;formId&quot;:&quot;c675ff17-5670-48c4-b23a-d095a334110b&quot;,&quot;formInstanceId&quot;:&quot;2711&quot;,&quot;pageId&quot;:&quot;23647102684&quot;,&quot;pageName&quot;:&quot;NovaBACKUP, The #1 Windows Backup Software&quot;,&quot;inlineMessage&quot;:true,&quot;rawInlineMessage&quot;:&quot;Thanks for submitting the form.&quot;,&quot;hsFormKey&quot;:&quot;9b409764ddd6b474388baa62adfa7e35&quot;,&quot;target&quot;:&quot;#hs_form_target_module_1550221074219543&quot;,&quot;abTestId&quot;:23647102682,&quot;contentType&quot;:&quot;standard-page&quot;,&quot;formData&quot;:{&quot;cssClass&quot;:&quot;hs-form stacked hs-custom-form&quot;},&quot;hutk&quot;:&quot;3988fb5ea814daa3dc569f2bfc518bc7&quot;},&quot;pageId&quot;:&quot;23647102684&quot;,&quot;pageName&quot;:&quot;NovaBACKUP, The #1 Windows Backup Software&quot;,&quot;formInstanceId&quot;:&quot;2711&quot;,&quot;formValidity&quot;:{&quot;email&quot;:{&quot;valid&quot;:true}},&quot;rawInlineMessage&quot;:&quot;Thanks for submitting the form.&quot;,&quot;hsFormKey&quot;:&quot;9b409764ddd6b474388baa62adfa7e35&quot;,&quot;formTarget&quot;:&quot;#hs_form_target_module_1550221074219543&quot;,&quot;abTestId&quot;:23647102682,&quot;correlationId&quot;:&quot;21fccf79-53bd-4fd6-a497-d8ac4a8c6e0a&quot;,&quot;contentType&quot;:&quot;standard-page&quot;,&quot;hutk&quot;:&quot;3988fb5ea814daa3dc569f2bfc518bc7&quot;,&quot;isHostedOnHubspot&quot;:true}" data-reactid=".hbspt-forms-1.7"><iframe name="target_iframe_c675ff17-5670-48c4-b23a-d095a334110b_2711" style="display:none;" data-reactid=".hbspt-forms-1.8"></iframe></form></div>








</span>

</div>

</div><!--end widget-span -->
</div><!--end row-->
</div><!--end row-wrapper -->

</div><!--end widget-span -->
</div><!--end row-->
</div><!--end row-wrapper -->

</div><!--end widget-span -->
</div><!--end row-->
</div><!--end row-wrapper -->

</div><!--end widget-span -->
</div><!--end row-->
</div><!--end row-wrapper -->

<div class="row-fluid-wrapper row-depth-1 row-number-10 ">
<div class="row-fluid ">
<div class="span12 widget-span widget-type-custom_widget " style="" data-widget-type="custom_widget" data-x="0" data-w="12">
<div id="hs_cos_wrapper_module_156384440527500" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_module" style="" data-hs-cos-general-type="widget" data-hs-cos-type="module"><script>
$(".toggle-but").click(function(event){
$(".toggle-but.active").removeClass("active");
$("#"+$(this).addClass("active").attr("title")).show().closest(".row-fluid-wrapper").siblings().find(".listing-item").hide();
return false;
});
/*
* jQuery Reveal Plugin 1.0
* www.ZURB.com
* Copyright 2010, ZURB
* Free to use under the MIT license.
* http://www.opensource.org/licenses/mit-license.php
*/
(function ($) {
$('a[data-reveal-id]').on('click', function (event) {
event.preventDefault();
var modalLocation = $(this).attr('data-reveal-id');
console.log("opening " + modalLocation);
$('#' + modalLocation).reveal($(this).data());
});
$.fn.reveal = function (options) {
var defaults = {
animation: 'fade',                // fade, fadeAndPop, none
animationSpeed: 200,                    // how fast animtions are
closeOnBackgroundClick: true,           // if you click background will modal close?
dismissModalClass: 'close-reveal-modal' // the class of a button or element that will close an open modal
};
var options = $.extend({}, defaults, options);
return this.each(function () {
var modal    = $(this),
topMeasure = parseInt(modal.css('top')),
topOffset  = modal.height() + topMeasure,
locked     = false,
modalBg    = $('.reveal-modal-bg');
if (modalBg.length == 0) {
modalBg = $('<div class="reveal-modal-bg" />').insertAfter(modal);
modalBg.fadeTo('fast', 0.8);
}
function openAnimation() {
modalBg.unbind('click.modalEvent');
$('.' + options.dismissModalClass).unbind('click.modalEvent');
if (!locked) {
lockModal();
if (options.animation == "fadeAndPop") {
modal.css({'top': $(document).scrollTop() - topOffset, 'opacity': 0, 'visibility': 'visible'});
modalBg.fadeIn(options.animationSpeed / 2);
modal.delay(options.animationSpeed / 2).animate({
"top": $(document).scrollTop() + topMeasure + 'px',
"opacity": 1
}, options.animationSpeed, unlockModal);
}
if (options.animation == "fade") {
modal.css({'opacity': 0, 'visibility': 'visible', 'top': $(document).scrollTop() + topMeasure});
modalBg.fadeIn(options.animationSpeed / 2);
modal.delay(options.animationSpeed / 2).animate({
"opacity": 1
}, options.animationSpeed, unlockModal);
}
if (options.animation == "none") {
modal.css({'visibility': 'visible', 'top': $(document).scrollTop() + topMeasure});
modalBg.css({"display": "block"});
unlockModal();
}
}
modal.unbind('reveal:open', openAnimation);
}
modal.bind('reveal:open', openAnimation);
function closeAnimation() {
if (!locked) {
lockModal();
if (options.animation == "fadeAndPop") {
modalBg.delay(options.animationSpeed).fadeOut(options.animationSpeed);
modal.animate({
"top":  $(document).scrollTop() - topOffset + 'px',
"opacity": 0
}, options.animationSpeed / 2, function () {
modal.css({'top': topMeasure, 'opacity': 1, 'visibility': 'hidden'});
unlockModal();
});
}
if (options.animation == "fade") {
modalBg.delay(options.animationSpeed).fadeOut(options.animationSpeed);
modal.animate({
"opacity" : 0
}, options.animationSpeed, function () {
modal.css({'opacity': 1, 'visibility': 'hidden', 'top': topMeasure});
unlockModal();
});
}
if (options.animation == "none") {
modal.css({'visibility': 'hidden', 'top': topMeasure});
modalBg.css({'display': 'none'});
}
}
modal.unbind('reveal:close', closeAnimation);
}
modal.bind('reveal:close', closeAnimation);
modal.trigger('reveal:open');
var closeButton = $('.' + options.dismissModalClass).bind('click.modalEvent', function () {
modal.trigger('reveal:close');
});
if (options.closeOnBackgroundClick) {
modalBg.css({"cursor": "pointer"});
modalBg.bind('click.modalEvent', function () {
modal.trigger('reveal:close');
});
}
$('body').keyup(function (event) {
if (event.which === 27) { // 27 is the keycode for the Escape key
modal.trigger('reveal:close');
}
});
function unlockModal() {
locked = false;
}
function lockModal() {
locked = true;
}
});
};
})(jQuery);
</script></div>

</div><!--end widget-span -->
</div><!--end row-->
</div><!--end row-wrapper -->
</div><!-- end coded_template: id:9876203527 path:generated_global_groups/9876203526.html -->

</div><!--end widget-span -->
</div><!--end row-->
</div><!--end row-wrapper -->

<div class="row-fluid-wrapper row-depth-1 row-number-2 ">
<div class="row-fluid ">
<div class="span12 widget-span widget-type-global_group " style="" data-widget-type="global_group" data-x="0" data-w="12">
<!-- start coded_template: id:7422319579 path:generated_global_groups/7422319578.html -->
<div class="" data-global-widget-path="generated_global_groups/7422319578.html"><div class="row-fluid-wrapper row-depth-1 row-number-1 ">
<div class="row-fluid ">
<div class="span12 widget-span widget-type-custom_widget " style="" data-widget-type="custom_widget" data-x="0" data-w="12">
<div id="hs_cos_wrapper_module_1530645122649432" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_module" style="" data-hs-cos-general-type="widget" data-hs-cos-type="module"><!-- act21.min.js required by all components. Please do not delete. -->
<script src="https://cdn2.hubspot.net/hubfs/273774/mp/act2/js/act21.min.js"></script>
<script>
function displayPressContact(){
document.getElementById("pressContact").style.display = "block";
}
if (isPress == 1){
console.log("Display Press contact.")
displayPressContact()
}
</script></div>

</div><!--end widget-span -->
</div><!--end row-->
</div><!--end row-wrapper -->
</div><!-- end coded_template: id:7422319579 path:generated_global_groups/7422319578.html -->

</div><!--end widget-span -->
</div><!--end row-->
</div><!--end row-wrapper -->

    </div><!--end footer -->
</div>

<footer>
    <style>
        .prpricesec{ display:none; }
    </style>
    <script>
        $('div.select').show();
        $('.prpricesec').show();

        $('.styledSelect').click(function (e) {
                e.stopPropagation();
                $(this).toggleClass('active').next('.options').toggle();
            });

        $('.select li').click(function (e) {
            e.stopPropagation();
            var select = $(this).closest('.select'), table = $(this).closest('#cloudSection'), amount = $(this).attr('rel');
            select.find('.styledSelect').html($(this).html()).removeClass('active');
            select.find(".selectVal").val(amount);
            select.find('.options').hide();
            if(amount>0 && !table.hasClass("has_cloud")) table.addClass("has_cloud");
            else if (amount == 0 && table.hasClass("has_cloud")) table.removeClass("has_cloud");
            $('.prprice').html((parseFloat($(this).data("price")) * <?php echo $percentTimeRemaining??1 ?>).toFixed(2));
        });

        $(document).click(function () {
            $('.select .styledSelect').removeClass('active');
            $('.select .options').hide();
        });

        $('#myForm').one('submit', function() {
            $(this).find('input[type="submit"]').attr('disabled','disabled');
        });
    </script>
</footer>