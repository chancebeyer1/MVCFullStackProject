<!DOCTYPE html>
<html>
<body>

<form action="./scrapeBuffaloSubmission" id="usrform" method="POST">
<div>Enter form submission email here...</div>
<textarea rows="40" cols="50" name="submission">
</textarea>
<br>
  <input type="submit">
</form>

</body>
</html>
